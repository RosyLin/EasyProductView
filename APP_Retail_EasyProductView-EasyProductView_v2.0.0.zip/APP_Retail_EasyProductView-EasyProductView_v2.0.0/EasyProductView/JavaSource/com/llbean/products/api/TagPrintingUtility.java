package com.llbean.products.api;

import java.net.URL;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class TagPrintingUtility {
	
	public static String getTagPrintingURL(){
		final String TagPrintingBaseURL = "url/TagPrintingURL";
		Context context;
		URL proxyURL = null;
		try {
			context = new InitialContext();
			proxyURL = (URL) context.lookup(TagPrintingBaseURL);
		} catch (NamingException e) {
			// Create log4j file here to log exceptions
		}
		
		return proxyURL.toString();
	}
}
