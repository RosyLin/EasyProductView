package com.llbean.products.api;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.wink.client.Resource;
import org.apache.wink.client.RestClient;

@Path("/getSkuInfo/{productID}/store/{storeNum}")
public class GetSkuInformation {
	// GET request
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public Response sendGet(@PathParam("productID") final String productID, @PathParam("storeNum") final String storeNum){
		
		String json = null;
		for (int tryNum = 1; tryNum <= 3; tryNum++) {
			try { 
	            RestClient client = new RestClient(); 
	            Resource resource = client.resource(TagPrintingUtility.getTagPrintingURL()+"/rest/tags/tag-details/" + productID + "/store/" + storeNum); 
	            json = resource.get(String.class);
	            
	            return Response.status(200).header("Access-Control-Allow-Origin", "*")
	    				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
	    				.header("Access-Control-Allow-Credentials", "true").header("Access-Control-Allow-Methods", "GET, HEAD")
	    				.header("Access-Control-Max-Age", "1209600").entity(json).build();
	        } catch (Exception e) { 
				if (tryNum == 3) {
					e.printStackTrace();
		            return Response.status(404).header("Access-Control-Allow-Origin", "*")
		    				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
		    				.header("Access-Control-Allow-Credentials", "true").header("Access-Control-Allow-Methods", "GET, HEAD")
		    				.header("Access-Control-Max-Age", "1209600").entity("[{\"message\" : \"Server error: We had trouble getting inventory information.\"}]").build();
				}
	        }
		}
		return Response.status(404).header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
				.header("Access-Control-Allow-Credentials", "true").header("Access-Control-Allow-Methods", "GET, HEAD")
				.header("Access-Control-Max-Age", "1209600").entity("[{\"message\" : \"Server error: We had trouble getting inventory information.\"}]").build();
	}
}