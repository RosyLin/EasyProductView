package com.llbean.products.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


@Path("/searchProducts/{freeText}")
public class SearchProducts {

	public String replace(String str) {
	    String[] words = str.split(" ");
	    StringBuilder sentence = new StringBuilder(words[0]);

	    for (int i = 1; i < words.length; ++i) {
	        sentence.append("%20");
	        sentence.append(words[i]);
	    }

	    return sentence.toString();
	}
	
	Config config = new Config();
	private final String KEY = config.getKey();

	// GET request
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response sendGet(@PathParam("freeText") final String freeText)
			throws Exception, IOException, ClassNotFoundException {

		String urlSearchText = replace(freeText);
		String url = ApigeeUtility.getApigeeURL() + "/search?freetext=" + urlSearchText;

		for (int tryNum = 1; tryNum <= 3; tryNum++) {
			try{
				URL obj = new URL(url);
				HttpURLConnection conn = (HttpURLConnection) obj.openConnection();

				// default is GET, but adding it anyway to be sure
				conn.setRequestMethod("GET");

				// add the key in the header
				conn.setRequestProperty("key", KEY);
				conn.setRequestProperty("Content-Type", "application/json; charset=\"utf-8\"");

				BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
				String inputLine;
				StringBuilder response = new StringBuilder();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();	
				
				JSONObject searchResponse = new JSONObject(response.toString());
			
				JSONArray resultsArrayForRetail = getRetailResults(urlSearchText);
				searchResponse.getJSONObject("properties").put("resultsForRetail", resultsArrayForRetail);
				
				return Response.status(200).header("Access-Control-Allow-Origin", "*")
						.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
						.header("Access-Control-Allow-Credentials", "true").header("Access-Control-Allow-Methods", "GET, HEAD")
						.header("Access-Control-Max-Age", "1209600").entity(searchResponse.toString()).build();
				
			} catch(Exception e) {
				if (tryNum == 3) {
					e.printStackTrace();
					return Response.status(404).header("Access-Control-Allow-Origin", "*")
							.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
							.header("Access-Control-Allow-Credentials", "true").header("Access-Control-Allow-Methods", "GET, HEAD")
							.header("Access-Control-Max-Age", "1209600").entity("[{\"message\" : \"Server error: We had trouble getting search results.\"}]").build();
				}
			}
		}
		return Response.status(404).header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
				.header("Access-Control-Allow-Credentials", "true").header("Access-Control-Allow-Methods", "GET, HEAD")
				.header("Access-Control-Max-Age", "1209600").entity("[{\"message\" : \"Server error: We had trouble getting search results.\"}]").build();
	}
	
	
	private JSONArray getRetailResults(String urlSearchText) throws IOException, JSONException{
		String url = ApigeeUtility.getApigeeURL() + "/search?freetext=" + urlSearchText + "&expand=retail";
		URL obj = new URL(url);
		HttpURLConnection conn = (HttpURLConnection) obj.openConnection();

		// default is GET, but adding it anyway to be sure
		conn.setRequestMethod("GET");

		// add the key in the header
		conn.setRequestProperty("key", KEY);
		conn.setRequestProperty("Content-Type", "application/json; charset=\"utf-8\"");

		BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
		String inputLine;
		
		StringBuilder responseForRetail = new StringBuilder();

		while ((inputLine = in.readLine()) != null) {
			responseForRetail.append(inputLine);
		}
		in.close();

		JSONObject o = new JSONObject(responseForRetail.toString());
		JSONArray p = o.getJSONObject("properties").getJSONArray("results");
		
		return p;
	}
}