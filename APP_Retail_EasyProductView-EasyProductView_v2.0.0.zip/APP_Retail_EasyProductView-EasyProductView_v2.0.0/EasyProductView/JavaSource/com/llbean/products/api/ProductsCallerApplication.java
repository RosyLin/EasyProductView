package com.llbean.products.api;
 
import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;
 
public class ProductsCallerApplication extends Application {
	
	@Override 
	public Set<Class<?>> getClasses() {
        Set<Class<?>> classes = new HashSet<Class<?>>();
        classes.add(GetProductDetail.class);
        classes.add(SearchProducts.class);
        classes.add(GetInventory.class);
        classes.add(GetPrintLocations.class);
        classes.add(GetPrintersAtLocation.class);
        classes.add(GetTagDetails.class);
        classes.add(PrintTags.class);
        classes.add(GetProductAttributes.class);
        classes.add(GetProductData.class);
        classes.add(GetPersonalization.class);
        classes.add(GetSkuInformation.class);
        classes.add(UPCtoSKUConverter.class);
        classes.add(SKUtoUPCConverter.class);
        return classes;
    }
}