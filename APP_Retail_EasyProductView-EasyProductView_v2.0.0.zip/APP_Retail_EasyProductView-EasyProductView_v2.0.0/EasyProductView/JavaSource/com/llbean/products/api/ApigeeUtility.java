package com.llbean.products.api;

import java.net.URL;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class ApigeeUtility {
	public static String getApigeeURL(){
		final String ApigeeBaseURL = "url/ApigeeProductsAPI";
		Context context;
		URL proxyURL = null;
		try {
			context = new InitialContext();
			proxyURL = (URL) context.lookup(ApigeeBaseURL);
		} catch (NamingException e) {
			// Create log4j file here to log exceptions
		}
		
		return proxyURL.toString();
	}
}
