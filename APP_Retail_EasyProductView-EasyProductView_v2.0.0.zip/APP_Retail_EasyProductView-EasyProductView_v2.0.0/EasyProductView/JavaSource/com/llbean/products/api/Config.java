package com.llbean.products.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Config {
	public String getKey() {
		InputStream input = null;
		String key = "";
		
		try {
			String configFileName = "config.properties";
			input = getClass().getClassLoader().getResourceAsStream(configFileName);
			BufferedReader reader = new BufferedReader(new InputStreamReader(input));
			String line;
			while ((line = reader.readLine()) != null) {
				if (line.startsWith("apiKey")) {
					key = line.substring(line.indexOf('=') + 1);
				}
			}
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return key;
	}
}
