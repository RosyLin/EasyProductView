package com.llbean.products.api;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/getProductData/{itemID}")
public class GetProductData {
	
	Config config = new Config();
	private final String KEY = config.getKey();

	// GET request
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response sendGet(@PathParam("itemID") final String itemID) {
        String url = "https://mw-retailsvcsqa-lb.llbean.com/RetailService/product/info?itemId=" + itemID;
		URL obj = null;
		try {
			obj = new URL(url);
		} catch (MalformedURLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		for (int tryNum = 1; tryNum <= 3; tryNum++) {
			try{
				HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
				
				// default is GET, but adding it anyway to be sure
				conn.setRequestMethod("GET");
				 
				// add the key in the header
				conn.setRequestProperty("key", KEY);
				conn.setRequestProperty("Content-Type", "application/json; charset=\"utf-8\"");
				
				BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
				String inputLine;
				StringBuilder response = new StringBuilder();

				while ((inputLine = in.readLine()) != null) {
					inputLine = inputLine.replaceAll("\uFFFD", "");
					response.append(inputLine);
				}
				in.close();

				String responseString = response.toString();
					
					return Response.status(200).header("Access-Control-Allow-Origin", "*")
						.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
						.header("Access-Control-Allow-Credentials", "true").header("Access-Control-Allow-Methods", "GET, HEAD")
						.header("Access-Control-Max-Age", "1209600").entity(responseString)
						.build(); 
			} catch (Exception e)  {
				if (tryNum == 3) {
					e.printStackTrace();
					return Response.status(404).header("Access-Control-Allow-Origin", "*")
							.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
							.header("Access-Control-Allow-Credentials", "true").header("Access-Control-Allow-Methods", "GET, HEAD")
							.header("Access-Control-Max-Age", "1209600").entity("[{\"message\" : \"Server error: We had trouble getting product detail\"}]")
							.build();
				}
			}
		}
		return Response.status(404).header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
				.header("Access-Control-Allow-Credentials", "true").header("Access-Control-Allow-Methods", "GET, HEAD")
				.header("Access-Control-Max-Age", "1209600").entity("[{\"message\" : \"Server error: We had trouble getting product detail\"}]")
				.build();
	}
}
