const GREEN = '#0C5641';
const LIGHT_GREEN = '#218838';

export { GREEN, LIGHT_GREEN };
