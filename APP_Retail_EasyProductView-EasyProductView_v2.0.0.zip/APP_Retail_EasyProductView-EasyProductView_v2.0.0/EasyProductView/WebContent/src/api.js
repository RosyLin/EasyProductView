import axios from 'axios';

const searchUrl = '/EasyProductView/rest/searchProducts';
const inventoryUrl = '/EasyProductView/rest/getInventory';
const locationsUrl = '/EasyProductView/rest/getPrintLocations';
const printersUrl = '/EasyProductView/rest/getPrintersAtLocation';
const personalizationUrl = '/EasyProductView/rest/getProductPersonalization';
const attributesUrl = '/EasyProductView/rest/getProductAttributes';
const detailsUrl = '/EasyProductView/rest/getProductDetail';
const skuInfoUrl = '/EasyProductView/rest/getSkuInfo';
const printTagsUrl = '/EasyProductView/rest/printTags/sku';
const skuToUpcUrl = '/EasyProductView/rest/SKUtoUPC';
const upcToSkuUrl = '/EasyProductView/rest/UPCtoSKU';
const productDataUrl = '/EasyProductView/rest/getProductData';


const search = (text, callback) => axios.get(`${searchUrl}/${text}`);
const getDetails = itemId => axios.get(`${detailsUrl}/${itemId}`);
const getAttributes = itemId => axios.get(`${attributesUrl}/${itemId}`);
const getPersonalization = itemId => axios.get(`${personalizationUrl}/${itemId}`);
const getInventory = itemID => axios.get(`${inventoryUrl}/${itemID}&merch=0&size=0`);
const getSkuInfo = (sku, store) => axios.get(`${skuInfoUrl}/${sku}/store/${store}`);
const getTagDetails = params => axios.get('/', params);
const getPrintTags = (sku, store, printer, tagType, quantity) => axios.get(`${printTagsUrl}/${sku}/store/${store}/printer/${printer}/tagType/${tagType}/quantity/${quantity}`);
const getPrinters = storeId => axios.get(`${printersUrl}/${storeId}`);
const getLocations = () => axios.get(`${locationsUrl}/`);
const getUPCfromSKU = sku => axios.get(`${skuToUpcUrl}/${sku}`);
const getSKUfromUPC = upc => axios.get(`${upcToSkuUrl}/${upc}`);
const getProductData = itemId => axios.get(`${productDataUrl}/${itemId}`);

export { inventoryUrl, locationsUrl, personalizationUrl, attributesUrl, detailsUrl, productDataUrl, search, getDetails, getAttributes, getPersonalization, getInventory, getProductData, getSkuInfo, getTagDetails, getPrintTags, getPrinters, getLocations, getUPCfromSKU, getSKUfromUPC };
