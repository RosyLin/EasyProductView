import 'bootstrap/dist/css/bootstrap.min.css';
import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import { CookiesProvider } from 'react-cookie';


ReactDOM.render(<BrowserRouter basename="/EasyProductView">
	<CookiesProvider>
		<App />
	</CookiesProvider>
</BrowserRouter>, document.getElementById('root'));
registerServiceWorker();