import React, { Component } from 'react';
import { Route } from 'react-router-dom';
import styled from 'styled-components';
import Header from './components/header/Header';
import Body from './containers/body/Body';
import Alert from 'react-s-alert';
import { instanceOf } from 'prop-types';
import { withCookies, Cookies } from 'react-cookie';

import 'react-s-alert/dist/s-alert-default.css';
import 'react-s-alert/dist/s-alert-css-effects/slide.css';

const DivContainer = styled.div`
	padding-left: 15px;
	padding-right: 15px;
`;

const HR = styled.hr`
	width: 98%;
	margin-left: 10px;
`;
class App extends Component {
	static propTypes = {
		cookies: instanceOf(Cookies).isRequired
	};

	constructor(props) {
		super(props);

		const { cookies } = props;
		this.state = {
			location: cookies.get('siteNumber') || null
		};
	}

	handleLocationChange = (location) => {
		const { cookies } = this.props;

		cookies.set('siteNumber', location, { path: '/', maxAge: 63113904 });
		this.setState({ location });
	};

	render = () => {
		const {location} = this.state;
		return (
			<DivContainer>
				<Header />
				<HR />
				<Route path="/product/:itemId(\d{6})" render={({ match: { params: { itemId } } }) => <Body itemId={itemId} location={location} handleLocationChange={this.handleLocationChange} />} />
				<Route path="/product/:sku([a-zA-Z\d]{5}\d{5})" render={({ match: { params: { sku } } }) => <Body sku={sku} location={location} handleLocationChange={this.handleLocationChange} />} />
				<Route path="/search/:text" render={({ match: { params: { text } } }) => <Body text={text} />} />
				<Alert stack={{ limit: 3 }} />
			</DivContainer >
		);
	}
	

}

export default withCookies(App);
