import { Button } from 'reactstrap';
import styled from 'styled-components';
import { GREEN } from '../../constants';

const button = styled(Button)`
	background-color: ${GREEN};
	border-radius: 5px;
	border: none;
	color: white;
	/* padding: 13px 20%; */
	text-align: center;
	text-decoration: none;
	display: inline-block;
	font-size: 16px;
	margin-bottom: 4px;
	line-height: 0;
`;

export default button;
