import styled from 'styled-components';

const squareButton = styled.button`
	color: white;
	display: block;
	float: left;
	cursor: pointer;
	width: 100px;
	height: 100px;
	border: none;

	:hover {
		background-color: #777;
	}
`;

export default squareButton;
