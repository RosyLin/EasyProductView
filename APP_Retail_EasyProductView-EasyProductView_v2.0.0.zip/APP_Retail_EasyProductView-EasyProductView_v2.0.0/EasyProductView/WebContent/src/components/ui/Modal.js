import React from 'react';
import Backdrop from './Backdrop';
import Image from './spinner.png';

import './Modal.css';

const modal = (props) => (
	<div>
		<Backdrop show={props.show} />
		<div 
			className="Modal"
			style={{
				transform: props.show ? 'translateY(0)' : 'translateY(-100vh)',
				opacity: props.show ? '1' : '0'
			}}>
			{props.children}
			<div className="ModalInnerDiv">
				<p>Loading, please wait</p>
				<img src={Image} alt="spinner" className="App-logo" />
			</div>
		</div>
	</div>
);

export default modal;

//<img src="../../images/spinner.png" alt="spinner" className="App-logo" />
//<img src="../../images/boot.jpg" alt="spinner" className="App-logo" />

