import Switch from "react-switch";
import styled from 'styled-components';

const switchButton = styled(Switch)`
    onColor = '0C5641';
    checked = true;
    height = 36;
    width = 70;
`;

export default switchButton;
