import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import { IconContext } from 'react-icons/lib';
import { TiHome } from 'react-icons/ti';
import { GREEN, LIGHT_GREEN } from '../../constants';

const Banner = styled.h1`
	float: left;
	font-size: 30px;
	color: ${GREEN};
	padding: 0px 15px 5px 0px;

	@media only all and (max-width: 520px) {
		font-size: 23px;
	}

	@media only all and (min-width: 348px) and (max-width: 430px) {
		font-size: 1.5em;
    	margin-left: -15px;
	}
`;

const IconLink = styled(Link)`
	color: ${GREEN};

	:hover {
		color: ${LIGHT_GREEN}
	}
`;

const value = {
	size: '1.25em',
	style: {
		position: 'relative',
		top: '-4px'
	}
};

const banner = () => (
	<Banner>
		<IconLink to="/">
			<IconContext.Provider value={value}>
				<TiHome />
			</IconContext.Provider>
		</IconLink>
		{' '}
		Easy Product View
	</Banner>
);

export default banner;
