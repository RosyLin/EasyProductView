import React from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import { Col, Row } from 'reactstrap';
import styled from 'styled-components';
import Banner from './Banner';
import SearchBar from '../../containers/header/SearchBar';

const DivHeader = styled.div`
	padding: 15px 0px 10px 15px;
`;

const header = () => (
	<DivHeader>
		<Row>
			<Col sm="9">
				<Banner />
			</Col>
		</Row>
		<Switch>
			<Route path="/(search|product)/:text" render={({ match: { params: { text } } }) => (
				<Row>
					<SearchBar text={text} />
				</Row>
			)} />
			<Route exact path="/" render={() => (
				<Row>
					<SearchBar />
				</Row>
			)} />
			<Redirect to="/" />
		</Switch>
	</DivHeader>
);

export default header;
