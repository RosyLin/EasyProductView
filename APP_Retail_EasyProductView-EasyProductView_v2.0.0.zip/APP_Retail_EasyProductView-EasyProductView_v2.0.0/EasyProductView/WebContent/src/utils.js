const isItemId = text => /^([0-9]{6})$/.test(text);

export { isItemId };

const isSku = text => /^([a-zA-Z0-9]{5}[0-9]{5})$/.test(text);

export { isSku };

const isUpc = text => /^([0-9]{12}|[0-9]{13}|[0-9]{14})$/.test(text);

export { isUpc };

const isSkuOrItemId = text => /^([0-9]{6}|[a-zA-Z0-9]{5}[0-9]{5})$/.test(text);

export { isSkuOrItemId };

const imageExists = (url, callback) => {
	const img = new Image();

	img.onload = () => {
		callback(true);
	};
	img.onerror = () => {
		callback(false);
	};
	img.src = url;
}

export { imageExists };

const getProdImgFromSwatch = (swatchUrl, callback) => {
	if (swatchUrl.includes('ecwebs01')) {
		const splitOnImages = swatchUrl.split('images/');
		const splitForProdId = splitOnImages[0].split('/');
		const prodId = splitForProdId[Number(splitForProdId.length) - 2];
		const imageNum = `M${prodId}_${splitOnImages[1]}`;
		swatchUrl = `${splitOnImages[0]}images/${imageNum}`;
		
		imageExists(swatchUrl, exists => {
			if (exists === true) {
				callback(swatchUrl);
			} else {
				callback(null);
			}
		});
	} else if (swatchUrl.includes('cdni')) {
		let imageId = Number(swatchUrl.substr(swatchUrl.length - 1));
		let swatchUrlNoImageId = swatchUrl.substring(0, swatchUrl.length - 1)

		imageId = imageId - 2;

		swatchUrl = swatchUrlNoImageId + imageId;

		imageExists(swatchUrl, exists => {
			if (exists === true) {
				callback(swatchUrl);
			} else {
				callback(null);
			}
		});
	} else {
		callback(null);
	}
}

export { getProdImgFromSwatch };