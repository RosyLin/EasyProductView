import React, { Component, Fragment } from 'react';
import { Route, withRouter } from 'react-router-dom';
import { Col, Input, InputGroup } from 'reactstrap';
import styled from 'styled-components';
import { IconContext } from 'react-icons/lib';
import { TiArrowBack } from 'react-icons/ti';
import * as utils from '../../utils';
import * as api from '../../api';
import Button from '../../components/ui/Button';

const ColSearch = styled(Col)`
	position: initial;
	margin-bottom: 10px;

	@media only all and (min-width: 496px) {
		min-width: 481px;
	}

	@media only all and (max-width: 496px) {
		width: 100%;
		padding-left: 0px;
	}
`;

const InputSearch = styled(Input)`
	font-size: 16px;
	height: 50px;

	@media only all and (max-width: 496px) {
		border-radius: 5px 5px 0px 0px !important;
	}

	@media only all and (max-width: 392px) {
		&::placeholder {
			font-size: 14px;
		}
	}

	@media only all and (max-width: 354px) {
		&::placeholder {
			font-size: 11.6px;
		}
	}
`;

const ButtonSearch = styled(Button)`
	height: 50px;
	border-radius: 0px 5px 5px 0px;

	@media only all and (max-width: 496px) {
		width: 100%;
		border-radius: 0px 0px 5px 5px;
	}
`;

const ColBack = styled(Col)`
	width: auto;
	margin: 0px;
	flex: 0;
	max-width: 41.666667%;

	@media only all and (max-width: 767px) {
		position: absolute;
		top: 10px;
		right: 10px;
	}

	@media only all and (max-width: 348px) {
		top: 45px;
	}
`;

const ButtonBack = styled(Button)`
	width: 200px;
	height: 50px;
	padding: 13px 9%;
	margin: 0px;

	@media only all and (max-width: 767px) {
		width: 80px;
		height: 40px;
	}
`;

const value = {
	size: '1.25em',
	style: {
		position: 'relative',
		top: '-2px'
	}
};

class SearchBar extends Component {
	state = {
		text: this.props.text || ''
	};

	showBackButton = !utils.isSkuOrItemId(this.state.text);

	onChange = ({ target: { value: text } }) => {
		this.setState({ text });
	};

	onKeyPress = ({ charCode }) => {
		if (charCode === 13) {
			this.onClickSearch();
		}
	};

	onClickSearch = async () => {
		if (utils.isSkuOrItemId(this.state.text)) { //either a SKU or ItemID
			this.showBackButton = false;
			if (utils.isSku(this.state.text)) {
				const upperSku = this.state.text.toUpperCase();
				this.props.history.push(`/product/${upperSku}`);
			} else {
				this.props.history.push(`/product/${this.state.text}`);
			}
		} else if (utils.isUpc(this.state.text)) { // working with a UPC here
			// convert upc to sku and do the same as above
			const sku = await api.getSKUfromUPC(this.state.text);
			const upperSku = sku.data.skus[0].skuID.toUpperCase();
			this.props.history.push(`/product/${upperSku}`);
		} else if (this.state.text) {
			this.showBackButton = true;

			this.props.history.push(`/search/${this.state.text}`);
		}
	};

	onClickBack = () => {
		this.props.history.push(`/search/${this.state.text}`);
	};

	render = () => {
		return (
			<Fragment>
				<ColSearch sm="7">
					<InputGroup>
						<InputSearch type="text" placeholder="Search for items by Item ID, SKU, UPC, or Keyword..." autoFocus={!this.state.text} value={this.state.text} onChange={this.onChange} onKeyPress={this.onKeyPress}/>
						<ButtonSearch color="success" onClick={this.onClickSearch}>Search</ButtonSearch>
					</InputGroup>
				</ColSearch>
				<Route path="/product" render={() => 
						this.showBackButton ? (
							<ColBack sm="5">
								<ButtonBack color="success" onClick={this.onClickBack}>
									<IconContext.Provider value={value}>
										<TiArrowBack /> Back
									</IconContext.Provider>
								</ButtonBack>
							</ColBack>
						) : null
					}
				/>
			</Fragment>
		);
	};
}

export default withRouter(SearchBar);
