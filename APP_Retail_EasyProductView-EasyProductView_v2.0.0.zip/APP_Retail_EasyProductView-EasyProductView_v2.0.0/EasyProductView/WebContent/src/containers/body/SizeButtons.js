import React, { Component } from 'react'; 
import { withRouter } from 'react-router-dom'; 
import styled from '../../../node_modules/styled-components'; 
import { GREEN } from '../../constants'; 
import SquareButton from '../../components/ui/SquareButton'; 
import 'airbnb-js-shims'; 

const DivFull = styled.div` 
    width: 100%; 
`; 

const ButtonSize = styled(SquareButton)` 
    width: 25%; 
    max-width: 120px; 
    height: 50px; 
    background-color: ${({ isCurrent }) => isCurrent ? GREEN : '#555'}; 
    border: ${({ isCurrent }) => isCurrent ? '5px solid cornflowerblue' : null};

    :hover { 
        background-color: ${({ isCurrent }) => isCurrent ? GREEN : '#777'}; 
        cursor: ${({ isCurrent }) => isCurrent ? "default" : "pointer"}; 
    } 
`; 

const ButtonSizeDark = styled(SquareButton)` 
    width: 25%; 
    max-width: 120px; 
    height: 50px; 
    background-color: ${({ isCurrent }) => isCurrent ? GREEN : '#222'}; 
    border: ${({ isCurrent }) => isCurrent ? '5px solid cornflowerblue' : null};

    :hover { 
        background-color: ${({ isCurrent }) => isCurrent ? GREEN : '#777'}; 
        cursor: ${({ isCurrent }) => isCurrent ? "default" : "pointer"}; 
    } 
`; 

class SizeButtons extends Component { 
    constructor(props) {
        super(props);
        this.state = {
          selectedSizeIndex: null,
        };
      }

    onClick = (size, sizeIndex) => { 
        this.props.setSize(size); 
        this.props.setSizeIndex(sizeIndex); 
        this.setState({ selectedSizeIndex: sizeIndex });
    }; 

    validSizeButtons = () => { 
        let buttons = []; 

        let availability = Object.keys(this.props.inventory); //AVAILABLE products skus, including duplicating color bc of different sizes 
        let attributes = this.props.skuMap.map(skuMap => skuMap.sku); //all product skus 
        let allSizes = this.props.skuMap.map(skuMap => skuMap.size); 
        let sizeNumbers = this.props.skuMap.map(skuMap => skuMap.sizeIndex); 
        let sizeNames = this.props.skuMap.map(skuMap => skuMap.size); //all size index 

        const matchingSize = new Map(); 
        for (var k in allSizes) 
        { 
            matchingSize.set(allSizes[k], {isAvailable: false, sizeIndex: sizeNumbers[k], size: sizeNames[k]});  
        } 
        for (var i in attributes) 
        { 
            for (var j in availability) 
            { 
                if (attributes[i] === availability[j]) 
                { 
                    matchingSize.set(allSizes[i], {isAvailable: true, sizeIndex: sizeNumbers[i], size: sizeNames[i]}); 
                } 
            } 
        } 
        for(const [key, value] of matchingSize) 
        { 
            let sizeIndex = value.sizeIndex; 
            
            if (value.isAvailable === true) 
            { 
                buttons.push( 
                        <ButtonSizeDark key={sizeIndex} isCurrent={value.size === this.props.size} onClick={() => value.size === this.props.size ? null : this.onClick(value.size, sizeIndex)} style={sizeIndex === this.state.selectedSizeIndex
                            ? { border: '7px solid #7abfff' }: null} > 
                            {value.size} 
                        </ButtonSizeDark> 
                ) 
            } 
            else { 
                buttons.push( 
                    <ButtonSize key={sizeIndex} isCurrent={value.size === this.props.size} onClick={() => value.size === this.props.size ? null : this.onClick(value.size, sizeIndex)} style={sizeIndex === this.state.selectedSizeIndex
                        ? { border: '7px solid #7abfff' }: null} >  
                            {value.size} 
                    </ButtonSize> 
                ) 
            } 
        } 
        if (buttons.length === 1 && buttons[0].props.isCurrent === false) 
        { 
            const autoClickButton = buttons[0]; 
            const sizeIndex = autoClickButton.key; 
            autoClickButton.props.onClick(autoClickButton.props.children, sizeIndex); 

        } 
        return buttons; 
    } 

    render = () => ( 
        <DivFull> 
            <p><b>Sizes:</b></p> 
            {this.validSizeButtons()} 
        </DivFull> 
    ); 
} 

export default withRouter(SizeButtons); 