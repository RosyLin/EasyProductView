import React, { Component, Fragment } from 'react';
import { Col, Row } from 'reactstrap';
import styled from 'styled-components';
import * as api from '../../api';
import * as utils from '../../utils';
import BasicInfo from './BasicInfo';
import TagPrinting from './TagPrinting';
import Inventory from './Inventory';
import ItemIdButtons from './ItemIdButtons';
import SizeButtons from './SizeButtons';
import ColorButtons from './ColorButtons';
import Copy from './Copy';
import Personalization from './Personalization';
import WebLinkButton from './WebLinkButton';
import Image from './image_not_found.png';
import 'airbnb-js-shims';
import './DetailPageStyle.css';

let attributesMissing = false;
const P = styled.p`
	margin-left: 10px;
	color: red;
`;

class ProductDetails extends Component {
	state = {
		details: null,
		attributes: null,
		productData: null,
		personalization: null,
		size: null,
		color: null,
		sizeIndex: null,
		colorIndex: null,
		swatchUrl: null,
		salePriceAndStatus: null
	};

	componentDidMount = async () => {
		this.props.showModal()
		if (!this.props.itemId) {
			this.props.setItemId((await api.search(this.props.sku)).data.properties.results[0].itemid);
		} else {
			this.getInfo();
		}
	};

	componentDidUpdate = async ({ itemId }) => {
		if (itemId !== this.props.itemId) {
			if (!this.props.itemId) this.props.setItemId((await api.search(this.props.sku)).data.properties.results[0].itemid);
			this.clearSizesAndColors();
			this.clearSalePriceAndStatus();
			this.getInfo();
		}
	};

	getInfo = () => {
		this.props.showModal();
		this.getDetails(this.props.itemId);
		this.getInventory();
		this.getPersonalization();
		this.getAttributes();
		this.getProductData();
	};

	clearSalePriceAndStatus = () => this.setState({ salePriceAndStatus: null });

	getSalePriceAndStatus = async () => {
		if (this.props.sku && this.props.location) {
			let response = await api.getSkuInfo(this.props.sku, this.props.location);
			await this.setState({ salePriceAndStatus: response.data.tagDetails[0] });
		} else {
			this.clearSalePriceAndStatus();
		}
	};

	getDetails = async itemId => {
		this.setState({ details: (await api.getDetails(itemId)).data });
		if (this.state.productData && this.state.details) this.props.hideModal();
	};

	getInventory = async () => {
		const { data: { properties: { skus, tableInfo: { locationList } } } } = await api.getInventory(this.props.itemId);
		const inventory = skus.map(sku => sku.filter(skuInv => skuInv.available && skuInv.onHandQty > 0 && skuInv.inventoryLocationId != null).map(skuInv => {
			const newSkuInv = { ...skuInv };

			try {
				newSkuInv.location = locationList.find(location => location.Id === skuInv.inventoryLocationId).SortDesc.trim();
			} catch (error) {
				console.error(error);
			}

			return newSkuInv;
		})).filter(sku => sku.length).reduce((obj, sku) => {
			obj[sku[0].skuId] = sku;

			return obj;
		}, {});

		this.props.setInventory(inventory);
		if (this.state.productData && this.state.details) this.props.hideModal();
	};

	getAttributes = async () => {
		attributesMissing = false;
		try {
			const attributes = (await api.getAttributes(this.props.itemId)).data.properties;

			attributes.skuMap.sort(({ sizeIndex: a }, { sizeIndex: b }) => Number(a) - Number(b));
			await this.setState({ attributes: attributes });
			if (this.props.sku) {
				const skuInfo = attributes.skuMap.find(obj => obj.sku === this.props.sku);
				this.setColor(skuInfo.color);
			}
			if (this.state.attributes && this.state.details) this.props.hideModal();
		} catch (error) { //for the cases where colors and sizes are not available.
			attributesMissing = true;
			this.props.hideModal()
		}
	};

	getProductData = async () => {
		let productDataMissing = false;
		try {
			const productData = (await api.getProductData(this.props.itemId)).data;
			await this.setState({ productData: productData });

			if (this.props.sku) {
				const skuInfo = productData.skuMap.find(obj => obj.sku === this.props.sku);
				this.setSize(skuInfo.size);
				this.setColor(skuInfo.color);
				this.setSizeIndex(skuInfo.sizeIndex);
				this.setColorIndex(skuInfo.colorIndex);
				this.setStatus(skuInfo.status);
			}
			
			if (this.state.productData && this.state.details) this.props.hideModal();
		} catch (error) { //for the cases where colors and sizes are not available.
			productDataMissing = true;
			this.props.hideModal()
		}
	};

	getPersonalization = async () => {
		const response = await api.getPersonalization(this.props.itemId);
		await this.setState({ personalization: response.data.properties.personalization });
		if (this.state.productData && this.state.details) this.props.hideModal();
	};

	clearSizesAndColors = () => {
		this.setState({ 
			details: null, size: null, color: null, sizeIndex: null, productData: null, skuMap: null, personalization: null,
			colorIndex: null, swatchUrl: null, attributes:null, swatches: null });
			this.props.setInventory(null);
	};

	skuMapFilter = (obj) => {
		return obj.size === this.state.size && obj.color === this.state.color;
	}

	setSku = () => {
		if (this.state.sizeIndex !== null && this.state.colorIndex !== null) {
			this.props.setSku(this.state.productData.skuMap.find(this.skuMapFilter).sku);
		} else {
			this.props.setSku(null);
		}
		this.getSalePriceAndStatus();
		this.setProdImg();
	}

	getIndexByColor(swatches, color) {
		for (let i = 0; i < swatches.length; i++) {
		  if (swatches[i].color === color) {
			return i;
		  }
		}
		return 0;
	  }

	setProdImg = () => {
		if (this.state.attributes) {
			let keyIndex = this.getIndexByColor(this.state.attributes.swatches, this.state.color);
			utils.getProdImgFromSwatch(this.state.attributes.swatches[keyIndex].swatchUrl, newUrl => {
				this.setSwatchUrl(newUrl);
			});
			
		}
	}

	setSize = size => {
		this.setState({ color: null, colorIndex: null });
		this.setState({ size });
		this.clearSalePriceAndStatus();
	};

	setColor = async color => {await this.setState({ color });
	this.setSku();
	}

	setStatus = status => this.setStatus({status});

	setSizeIndex = async sizeIndex => {
		await this.setState({ sizeIndex });
		this.setSku();
	};

	setColorIndex = async colorIndex => {
		await this.setState({ colorIndex });
		
	};

	getSize = () => {
        return this.state.size;
    };

	getColor = () => {
        return this.state.color;
    };

	setSwatchUrl = swatchUrl => this.setState({ swatchUrl });

	setLocation = (location) => {
		this.props.handleLocationChange(location);
		this.getSalePriceAndStatus();
	};

	render = () => {
		if (this.state.details && this.state.attributes && this.state.productData && this.props.inventory) {
			return (
				<Fragment>
					<Col sm='4'>
						<Row>
							<BasicInfo salePriceAndStatus={this.state.salePriceAndStatus} description={this.state.details.properties.desc} sku={this.props.sku} upc={this.props.upc} itemId={this.state.details.properties.itemid} regularPrice={this.state.attributes.fullRetailPrice} image={this.state.swatchUrl ? this.state.swatchUrl : this.state.details.links.find(link => link.title === 'defaultImgUrl') ? this.state.details.links.find(link => link.title === 'defaultImgUrl').link : Image} />
						</Row>
						<br />
						<Row>
							<TagPrinting sku={this.props.sku} location={this.props.location} handleLocationChange={this.setLocation} />
						</Row>
						<br />
						<Row>
							<Inventory classTitle={"twoColInv"} sku={this.props.sku} inventory={this.props.inventory[this.props.sku] || []} />
						</Row>
						<br />
					</Col>
					<Col sm='8'>
						<Row>
							<ItemIdButtons items={this.state.details.properties.items} itemId={this.state.details.properties.itemid} clearSizesAndColors={this.clearSizesAndColors} />
						</Row>
						<br />
						<Row>
							<SizeButtons inventory={this.props.inventory} skuMap={this.state.productData.skuMap} size={this.state.size} sizeIndex={this.state.sizeIndex} setSize={this.setSize} setSizeIndex={this.setSizeIndex} />
						</Row>
						<br />
						<Row>
							<ColorButtons inventory={this.props.inventory} skuMap={this.state.productData.skuMap} swatches={this.state.attributes.swatches} sizeIndex={this.state.sizeIndex} color={this.state.color} getSize={this.getSize} setColor={this.setColor} setColorIndex={this.setColorIndex} setSwatchUrl={this.setSwatchUrl} getColor = {this.getColor}/>
						</Row>
						<br />
						<Row>
							<Inventory classTitle={"oneColInv"} sku={this.props.sku} inventory={this.props.inventory[this.props.sku] || []} />
						</Row>
						<br />
						<Row>
							<Copy copy={this.state.details.properties.copy} />
							<Personalization personalization={this.state.personalization} />
						</Row>
						<br />
						<Row>
							<WebLinkButton links={this.state.details.links} />
						</Row>
					</Col>
				</Fragment>
			)
		} else if (attributesMissing) {
			// console.log('attributes are missing');
			return <Fragment>
				<Col sm='12'>
						<P>Sorry about that, we had issues loading that item, please refresh the page to try again.  If issues persist, use PIS to lookup the item.</P>
				</Col>
			</Fragment>
		} else {
			return null;
		}
	};
}

export default ProductDetails;
