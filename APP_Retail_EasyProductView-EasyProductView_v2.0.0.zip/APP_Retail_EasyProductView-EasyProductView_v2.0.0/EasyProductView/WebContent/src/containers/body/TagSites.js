import React, { Component } from 'react';
import { ButtonDropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
import styled from 'styled-components';

const SitesDropdown = styled(DropdownMenu)`
	height: 300px;
	overflow: scroll;
`;

const LocDropdownItem = styled(DropdownItem)`
	cursor: pointer;
`;

class TagSites extends Component {
	constructor(props) {
		super(props);

		this.toggle = this.toggle.bind(this);
		this.state = {
			dropdownOpen: false
		};
	}

	toggle = () => {
		this.setState({
			dropdownOpen: !this.state.dropdownOpen
		});
	};

	render = () => (
		<ButtonDropdown isOpen={this.state.dropdownOpen} toggle={this.toggle}>
			<DropdownToggle caret>
				{this.props.selectedLocation ? "Store " + this.props.selectedLocation : this.props.defaultText}
        	</DropdownToggle>
			<SitesDropdown>
				{this.props.locations.map(({ storeid: storeId }) => (
					<LocDropdownItem key={storeId} onClick={() => this.props.setLocation(storeId)}>
						Store {storeId}
					</LocDropdownItem>
				))}
			</SitesDropdown>
		</ButtonDropdown>

	);
}

export default TagSites;
