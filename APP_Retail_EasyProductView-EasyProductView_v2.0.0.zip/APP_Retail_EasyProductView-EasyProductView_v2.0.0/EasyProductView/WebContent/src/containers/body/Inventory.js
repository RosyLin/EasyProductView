import React, { Component } from 'react';
import { Col } from 'reactstrap';
import styled from 'styled-components';
import TableTwo from '../ui/TableTwo';

import './Inventory.css';

const H3 = styled.h3`
	margin-top: 35px;
`;

const Div = styled(Col)`
  @media only all and (min-width: 348px) and (max-width: 540px) {
	margin-left: -15px;
}
`;

class Inventory extends Component {

	render = () => {
		return (
			<Div className={this.props.classTitle}>
				<H3>Inventory</H3>
				<h6><b>This item is available in the following locations and quantities: </b></h6>
				<div className="TableDiv">
					<TableTwo rows={this.props.inventory} sku={this.props.sku} header="inventoryLocationId" />
				</div>
			</Div>
		);
	};
}

export default Inventory;