import React, { Component } from 'react';
import { Col } from 'reactstrap';
import styled from 'styled-components';


const Div = styled(Col)`
  @media only all and (min-width: 348px) and (max-width: 540px) {
	margin-left: -15px;
}
`;


class Personalization extends Component {
    render = () => {
		if (this.props.personalization) {
			return (
				<Div sm='6'>
					<h5><b>Personalization</b></h5>
					{this.props.personalization.map(({ name, content }, index) => (
						<p key={index}><b> {name}:  </b> {content.join(', ')}</p>
					))}
				</Div>
			)
		} else {
			return (
				<Div sm='6'>
					<h5><b>Personalization</b></h5>
					<p>No personalization available. </p>
				</Div>
			)
		}
		
	};
}

export default Personalization;
