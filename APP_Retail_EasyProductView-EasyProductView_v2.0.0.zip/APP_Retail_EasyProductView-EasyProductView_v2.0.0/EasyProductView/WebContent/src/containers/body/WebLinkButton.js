import React, { Component } from 'react';
import styled from 'styled-components';
import { GREEN } from '../../constants';
import SquareButton from '../../components/ui/SquareButton';

const LinkButton = styled(SquareButton)`
	width: 100%;
	background-color: ${GREEN};
	outline: none;
	min-height: 50px;
	margin-bottom: 5px;
`;

const NoLinkButton = styled(SquareButton)`
	width: 100%;
	background-color: ${GREEN};
	outline: none;
	min-height: 50px;
	margin-bottom: 5px;

	&:hover {
		background-color: ${GREEN};
		cursor: default;
	}
`;

const Div = styled.div`
	width: 100%;
`;

class WebLinkButton extends Component {
	onClick = () => {
		// console.log(this.props.links.find(link => link.title === 'weburl').link);
		window.location = this.props.links.find(link => link.title === 'weburl').link;
	}; //go to product page on website

	

	render = () => {
		if (this.props.links.find(link => link.title === 'weburl')) {
			return (
				<Div>
					<LinkButton onClick={() => this.onClick()}>
						Go to product page on LLBean.com
					</LinkButton>
				</Div>
			)
		} else {
			return (
				<Div>
					<NoLinkButton>
						No product page for this item on LLBean.com
					</NoLinkButton>
				</Div>
			)
		}
	};
}

export default WebLinkButton;
