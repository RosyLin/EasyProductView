import React, { Component } from 'react';
import { ButtonDropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
import styled from 'styled-components';

const PrinterDropdownItem = styled(DropdownItem)`
	cursor: pointer;
`;

class TagPrinters extends Component {
	constructor(props) {
		super(props);

		this.toggle = this.toggle.bind(this);
		this.state = {
			dropdownOpen: false
		};
	}

	toggle = () => {
		this.setState({
			dropdownOpen: !this.state.dropdownOpen
		});
	};

	render = () => (
		<ButtonDropdown isOpen={this.state.dropdownOpen} toggle={this.toggle}>
			<DropdownToggle caret>
				{this.props.selectedPrinterName ? this.props.selectedPrinterName : this.props.defaultText}
			</DropdownToggle>
			<DropdownMenu>
				{this.props.printers.map(({ DNS_NAME: printerName, IP_ADDRESS: printerIP }, index) => (
					<PrinterDropdownItem key={index} onClick={() => this.props.setPrinter(printerName, printerIP)}>
						{printerName}
					</PrinterDropdownItem>
				))}
			</DropdownMenu>
		</ButtonDropdown>

	);
}

export default TagPrinters;
