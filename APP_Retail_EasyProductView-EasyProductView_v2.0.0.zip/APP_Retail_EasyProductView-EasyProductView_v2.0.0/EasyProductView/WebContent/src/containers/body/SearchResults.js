import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import axios from 'axios';
import { injectGlobal } from 'styled-components';
import Table from '../ui/Table';

const searchUrl = '/EasyProductView/rest/searchProducts';

injectGlobal`
	.col-xs-7 {
		width: 64%;
	}

	::-webkit-scrollbar {
		display: none;
	}

	@media only all and (min-width: 768px) {
		.col-sm-5 {
			width: auto;
			margin: 0px;
		}
	}

	@media only all and (max-width: 496px) {
		.col-sm-5 {
			padding-left: 0px;
		}
	}
`;


class SearchResults extends Component {
	state = {
		awaitingResults: false,
	};

	componentDidMount = () => {
		if (!this.props.results.length) {
			this.props.showModal();
			this.search();
		}
	};

	componentDidUpdate = ({ text }) => {
		if (text !== this.props.text) {
			this.props.showModal();
			this.search();
		}
	};

	search = async () => {
		let results;
		let resultsForRetail;
		this.setState({awaitingResults: true});
		//console.log(this.state.awaitingResults);

		try {
			await axios.get(`${searchUrl}/${this.props.text}`).then(
				function (response) {
					results = response.data.properties.results;
					resultsForRetail = response.data.properties.resultsForRetail;
			});
			await this.setState({awaitingResults: false});
			//console.log(this.state.awaitingResults);
			await this.props.setResults([...results, ...resultsForRetail]);
			this.props.hideModal();
		} catch (error) {
			this.props.hideModal();
			await this.setState({awaitingResults: false});
		}
	};


	onClick = itemId => this.props.history.push(`/product/${itemId}`);
	render = () => 
		<Table rows={this.props.results}
			headers={['Item ID', 'Category', 'Name', 'Price']}
			header="itemid" data={['category', 'itemName', 'price']}
			widths={[10, 25, 40, 25]}
			//widths={[10, 40, 40, 10]}
			onClick={this.onClick}
			awaitingResults={this.state.awaitingResults}
		/>
}

export default withRouter(SearchResults);
