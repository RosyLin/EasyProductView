import React, { Component } from 'react';
import { Col } from 'reactstrap';
import styled from 'styled-components';

const ItemName = styled.h5`
	font-size: 1.8em;
`;

const ItemID = styled.p`
	font-size: 1.4em;
`;

const SkuInfo = styled.div`
	margin-bottom: 20px;
`;

const SkuHeaderText = styled.span`
	font-weight: bold;
	font-size: 1.4em;
`;

const SkuText = styled.span`
	font-size: 1.4em;
`;

const ProductImageDiv = styled.div`
	width: 100%;
	max-width: 325px;
	max-height: 350px;
`;

const ProductImage = styled.img`
	display: block;
	margin-left: 3%;
	margin-right: 3%;
	vertical-align: top;
	width: 100%;
	height: 100%;
	max-height: 350px;
`;

const RedP = styled.p`
	color: red;
`;

class BasicInfo extends Component {
	salePrice = () => {
		if (this.props.salePriceAndStatus) {
			if (this.props.salePriceAndStatus.SELLING_PRICE > 0) {
				return (
					<RedP><b>Sale Price: $</b>{this.props.salePriceAndStatus.SELLING_PRICE}</RedP>
				)
			} else {
				return null;
			}
		} else {
			return null;
		}
	};

	status = () => {
		if (this.props.salePriceAndStatus) {
			if (this.props.salePriceAndStatus.PRODUCT_STATUS === 'A') {
				return (
					<p><b>Status: </b>ACTIVE</p>
				)
			} else if (this.props.salePriceAndStatus.PRODUCT_STATUS === 'D') {
				return (
					<p><b>Status: </b>DISCONTINUED</p>
				)
			} else if (this.props.salePriceAndStatus.PRODUCT_STATUS === 'L') {
				return (
					<p><b>Status: </b>LIQUIDATED</p>
				)
			} else {
				return null;
			}
		} else {
			return null;
		}
	};

	render = () => {
		return(
			<Col>
				<ItemName>{this.props.description}</ItemName>
				<ItemID><b>Item ID: </b>{this.props.itemId}</ItemID>
				<SkuInfo>
					<SkuHeaderText>SKU: </SkuHeaderText>
					<SkuText data-toggle="tooltip" title="Double Click to Select Sku, Ctrl + C to copy">{this.props.sku}</SkuText>
				</SkuInfo>
				<SkuInfo>
					<SkuHeaderText>UPC: </SkuHeaderText>
					<SkuText data-toggle="tooltip" title="Double Click to Select UPC, Ctrl + C to copy">{this.props.upc}</SkuText>
				</SkuInfo>
				<p><b>Regular Price: </b>{this.props.regularPrice}</p>
				{this.salePrice()}
				{this.status()}
				<ProductImageDiv>
					<ProductImage src={this.props.image} />
				</ProductImageDiv>
			</Col>
		);
	}


}

export default BasicInfo;
