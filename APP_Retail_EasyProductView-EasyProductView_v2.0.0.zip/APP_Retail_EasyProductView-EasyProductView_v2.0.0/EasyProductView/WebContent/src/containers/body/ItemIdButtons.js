import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import styled from 'styled-components';
import { GREEN } from '../../constants';
import SquareButton from '../../components/ui/SquareButton'; 

const ItemButton = styled(SquareButton)`
	width: ${({ width_ }) => width_}%;
	min-width: 150px;
	max-width: 200px;
	background-color: ${({ isCurrent }) => isCurrent ? GREEN : '#555'};
	outline: none;
	min-height: 130px;
	border: ${({ isCurrent }) => isCurrent ? '7px solid #7abfff' : null};


	:hover {
		background-color: ${({ isCurrent }) => isCurrent ? GREEN : '#777'};
		cursor: ${({ isCurrent }) => isCurrent ? "default" : "pointer"};
	}
`;

class ItemIdButtons extends Component {
	onClick = itemID => {
		this.props.clearSizesAndColors();
		this.props.history.push(`/product/${itemID}`);
	};

    render = () => (
		<div>
			<p id="itemText"><b>Items:</b></p>
			{this.props.items.map(({ itemid: itemId, desc: description }) => (
				<ItemButton key={itemId} width_={100 / this.props.items.length} isCurrent={itemId === this.props.itemId} onClick={() => itemId === this.props.itemId ? null : this.onClick(itemId)}>
					{description}
				</ItemButton>
			))}
		</div>
	);
	
}

export default withRouter(ItemIdButtons);

