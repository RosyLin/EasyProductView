import React, { Component } from 'react';
import { Col } from 'reactstrap';
import styled from 'styled-components';

const Div = styled(Col)`
  @media only all and (min-width: 348px) and (max-width: 540px) {
	margin-left: -15px;
}
`;

class Copy extends Component {
    render = () => {
		if (this.props.copy[0]) {
			if(this.props.copy[0].items){//case for product specs array being returned
				return (
					<Div sm='6'>
						<h5> <b> Product Information </b> </h5>
						{this.props.copy[0].items.map(({ category, text }, index) => (
							<p key={index}><b> {category}:  </b>{text[0]}</p>
						))}
						{this.props.copy.slice(1).map(({ category, text }, index) => (
							<p key={index}><b> {category}:  </b> {text[0]}</p>
						))}
					</Div>
				)
			} 
			else {
				return (
					<Div sm='6'>
						<h5> <b> Product Information </b> </h5>
						{this.props.copy.map(({ category, text }, index) => (
							<p key={index}><b> {category}:  </b> {text[0]}</p>
						))}
					</Div>
				)
			}
		} else {
			return (
				<Div sm='6'>
					<h5> <b> Product Information </b> </h5>
					<p>No item description or specs available. </p>
				</Div>
			)
		}
        
    };
}

export default Copy;
