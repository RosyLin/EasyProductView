import React, { Component } from "react";
import Switch from "react-switch";
import styled from 'styled-components';

const SwitchButtonsDiv = styled.div`
	padding-top: 5px;
`;

class SwitchButton extends Component {
  constructor(props) {
    super(props);
    this.state = {...props, checked: true};
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(checked) {
    this.setState({ checked });
    this.state.switchCurrent(checked);
  }

  render() {
    return (
      <div>
        <b>Current Colors </b>
        <SwitchButtonsDiv>
        <Switch 
          onColor = "#0C5641" 
          offColor = "#888"
          onChange={this.handleChange} 
          checked={this.state.checked} 
        />
        </SwitchButtonsDiv>
      </div>
    );
  }
}

export default SwitchButton;