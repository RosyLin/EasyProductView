import React, { Component } from 'react';
import styled from 'styled-components';
import { GREEN } from '../../constants';
import SquareButton from '../../components/ui/SquareButton';
import { TiPrinter } from 'react-icons/ti';

const LinkButton = styled(SquareButton)`
	width: 90%;
	background-color: ${GREEN};
	outline: none;
	height: 50px;
	margin-bottom: 5px;
	margin-left: 5%;
	margin-right: 5%;
`;

class PrintButton extends Component {
	render = () => (
		<div>
			<LinkButton onClick={() => this.props.printTag()}>
				<TiPrinter />
				Print Price Tag(s)
			</LinkButton>
		</div>
	);
}

export default PrintButton;
