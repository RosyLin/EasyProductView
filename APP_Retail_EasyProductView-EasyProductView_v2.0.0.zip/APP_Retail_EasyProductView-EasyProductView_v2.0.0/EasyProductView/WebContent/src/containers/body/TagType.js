import React, { Component } from 'react';
import { ButtonDropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
import styled from 'styled-components';

const TypeDropdownItem = styled(DropdownItem)`
	cursor: pointer;
`;

class TagQuality extends Component {
	constructor(props) {
		super(props);

		this.toggle = this.toggle.bind(this);
		this.state = {
			dropdownOpen: false
		};
	}

	toggle = () => {
		this.setState({
			dropdownOpen: !this.state.dropdownOpen
		});
	};

	render = () => (
		<ButtonDropdown isOpen={this.state.dropdownOpen} toggle={this.toggle}>
			<DropdownToggle caret>
				{this.props.tagTypeName ? this.props.tagTypeName : this.props.defaultText}
			</DropdownToggle>
			<DropdownMenu>
				<TypeDropdownItem onClick={() => this.props.setTagType("firstQualityHard", "First Quality / Hard Tag")}>First Quality / Hard Tag</TypeDropdownItem>
				<TypeDropdownItem onClick={() => this.props.setTagType("firstQualitySticky", "First Quality / Sticky Tag")}>First Quality / Sticky Tag</TypeDropdownItem>
				<TypeDropdownItem onClick={() => this.props.setTagType("secondQualityHard", "Second Quality / Hard Tag")}>Second Quality / Hard Tag</TypeDropdownItem>
				<TypeDropdownItem onClick={() => this.props.setTagType("secondQualitySticky", "Second Quality / Sticky Tag")}>Second Quality / Sticky Tag</TypeDropdownItem>
			</DropdownMenu>
		</ButtonDropdown>

	);
}

export default TagQuality;
