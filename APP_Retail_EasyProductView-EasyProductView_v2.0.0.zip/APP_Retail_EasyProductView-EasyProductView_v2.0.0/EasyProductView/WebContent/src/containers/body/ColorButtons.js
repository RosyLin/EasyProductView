import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import styled from 'styled-components';
import { GREEN } from '../../constants';
import SquareButton from '../../components/ui/SquareButton';
import SwitchButton from './SwitchButton';

const ColorButtonsDiv = styled.div`
	width: 100%;
`;

const ButtonColorLight = styled(SquareButton)`
	width: 25%;
	max-width: 120px;
	height: 120px;
	background-color: ${({ isCurrent }) => isCurrent ? GREEN : '#888'};
	position: relative;
	border: ${({ isCurrent }) => isCurrent ? '7px solid #7abfff' : null};

	:hover {
		background-color: ${({ isCurrent }) => isCurrent ? GREEN : '#777'};
		cursor: ${({ isCurrent }) => isCurrent ? "default" : "pointer"};
	}
`;

const ButtonColorDark = styled(SquareButton)`
	width: 25%;
	max-width: 120px;
	height: 120px;
	background-color: ${({ isCurrent }) => isCurrent ? GREEN : '#222'};
	position: relative;
	border: ${({ isCurrent }) => isCurrent ? '7px solid #7abfff' : null};

	:hover {
		background-color: ${({ isCurrent }) => isCurrent ? GREEN : '#777'};
		cursor: ${({ isCurrent }) => isCurrent ? "default" : "pointer"};
	}
`;

const ImgFull = styled.img`
	width: 90%;
	height: 42px;
	color: #444;
	font-size: 8pt;
`;

const ContainerDiv = styled.div`
	width: 90%
	position: absolute;
	bottom: 5px;
`;

class ColorButtons extends Component {
	constructor(props) {
		super(props);
		this.state={...props, checked: true};
		this.handleCurrent = this.handleCurrent.bind(this);
	}

	async componentDidMount(){
		this.switchCurrent(true);
	}

	handleCurrent(buttons) {
			this.setState({ buttons });
		}
    
	onClick = async (color, colorIndex, swatchUrl) => {
		this.state.setColor(color);
		this.state.setColorIndex(colorIndex);
	};

	validColorButtons = () => {
		let buttons = [];
		let sizeResult = this.state.getSize();		

		if (sizeResult === null)
		{
			let availability = Object.keys(this.state.inventory);
			this.state.skuMap.sort(({ colorIndex: a }, { colorIndex: b }) => Number(a) - Number(b));
			let attributes = this.state.skuMap.map(skuMap => skuMap.sku);
			let allColors = this.state.skuMap.map(skuMap => skuMap.colorIndex);
			let colorNames = this.state.skuMap.map(skuMap => skuMap.color); 
			
			const matchingColor = new Map();
			if (this.state.checked === true)
			{
				allColors = this.state.skuMap.filter(skuMap => skuMap.status === "A" || skuMap.status === "L").map(skuMap => skuMap.colorIndex);
				colorNames = this.state.skuMap.filter(skuMap => skuMap.status === "A" || skuMap.status === "L").map(skuMap => skuMap.color);
				attributes = this.state.skuMap.filter(skuMap => skuMap.status === "A" || skuMap.status === "L").map(skuMap => skuMap.sku);
			}

			for (var k in allColors)
			{
				matchingColor.set(allColors[k], {isAvailable: false, colorIndex: allColors[k], color: colorNames[k]});
			}
			for (var i in attributes)
			{
				for (var j in availability)
				{
					if (attributes[i] === availability[j])
					{
						matchingColor.set(allColors[i], {isAvailable: true, colorIndex: allColors[i], color: colorNames[i]});
					}
				}
			}
			this.state.skuMap.sort(({ sizeIndex: a }, { sizeIndex: b }) => Number(a) - Number(b));
			
			for(const [key, value] of matchingColor)
			{
				let colorIndex = value.colorIndex;
				let color = value.color;
				const swatchData = this.state.swatches.find(swatch => swatch.color === color);

				if (value.isAvailable === true && swatchData !== undefined)
				{
					buttons.push(
						<ButtonColorDark key={colorIndex} isCurrent={swatchData.color === this.state.getColor()} onClick={() => this.onClick(swatchData.color, colorIndex, swatchData.swatchUrl)}>
							<ContainerDiv>
								{swatchData.color}
								<ImgFull src={swatchData.swatchUrl} alt="Image not available" />
							</ContainerDiv>
						</ButtonColorDark>
					)
				}
				if (value.isAvailable !== true && swatchData !== undefined) 
				{
					buttons.push(
						<ButtonColorLight key={colorIndex} isCurrent={swatchData.color === this.state.getColor()} onClick={() => this.onClick(swatchData.color, colorIndex, swatchData.swatchUrl)}>
							<ContainerDiv>
								{swatchData.color}
								<ImgFull src={swatchData.swatchUrl} alt="Image not available" />
							</ContainerDiv>
						</ButtonColorLight>
					)
				}
			}
		}
		//if click on size
		else {
			let sizeResult = this.state.getSize();
			let validSkuButtons = this.state.skuMap.filter(obj => obj.size === sizeResult);
			let inStockSkus = Object.keys(this.state.inventory);

			if (this.state.checked)
			{
				validSkuButtons = validSkuButtons.filter(skuMap => skuMap.status === "A" || skuMap.status === "L");
			}
			
			validSkuButtons.sort(({ colorIndex: a }, { colorIndex: b }) => Number(a) - Number(b));
			validSkuButtons.map(({ sku, colorIndex, color}) => {
				const swatchData = this.state.swatches.find(swatch => swatch.color === color);
				if (inStockSkus.includes(sku)) {
					buttons.push(
						<ButtonColorDark key={colorIndex} isCurrent={swatchData.color === this.state.getColor()} onClick={() => this.onClick(swatchData.color, colorIndex, swatchData.swatchUrl)}>
							<ContainerDiv>
								{swatchData.color}
								<ImgFull src={swatchData.swatchUrl} alt="Image not available" />
							</ContainerDiv>
						</ButtonColorDark>
					)
				} else {
					buttons.push(
						<ButtonColorLight key={colorIndex} isCurrent={swatchData.color === this.state.getColor()} onClick={() => this.onClick(swatchData.color, colorIndex, swatchData.swatchUrl)}>
							<ContainerDiv>
								{swatchData.color}
								<ImgFull src={swatchData.swatchUrl} alt="Image not available" />
							</ContainerDiv>
						</ButtonColorLight>
					)
				}
			});
		}
		return buttons;
	}
		
	switchCurrent = (checked) => {
		this.setState ({checked: checked});
		this.validColorButtons(checked);
	} 

	render = () => (
		<ColorButtonsDiv>
			<div><b>Colors:</b></div>
			<div><SwitchButton switchCurrent={this.switchCurrent}/></div>
			{this.validColorButtons()}
		</ColorButtonsDiv>
	);
}

export default withRouter(ColorButtons);
