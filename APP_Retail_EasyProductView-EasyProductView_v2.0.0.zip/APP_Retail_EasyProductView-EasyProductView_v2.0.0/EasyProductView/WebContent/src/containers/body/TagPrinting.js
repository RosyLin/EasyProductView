import React, { Component } from 'react';
import { ButtonGroup, Button, Col } from 'reactstrap';
import TagSites from './TagSites';
import TagPrinters from './TagPrinters';
import TagType from './TagType';
import PrintButton from './PrintButton';
import * as api from '../../api';
import styled from 'styled-components';
import Alert from 'react-s-alert';

import 'react-s-alert/dist/s-alert-default.css';
import 'react-s-alert/dist/s-alert-css-effects/slide.css';

const DropdownsButtonGroup = styled(ButtonGroup)`
	width: 100%;
	max-width: 325px;
	margin-bottom: 10px;
	margin-left: 3%;
	margin-right: 3%;
`;

const QuantityButtonGroup = styled(ButtonGroup)`
	width: 100%;
	max-width: 325px;
	margin-bottom: 10px;
	margin-left: 3%;
	margin-right: 3%;
`;

const QuantityAdjustButton = styled(Button)`
	width: 30%;
`;

const QuantityButton = styled(Button)`
	width: 34%;
	background-color: #333;
	&:hover {
		background-color: #333;
		cursor: default;
  	}
`;

const TagPrintDiv = styled.div`
	max-width: 325px;
`;

class TagPrinting extends Component {
	state = {
		locations: null,
		selectedLocation: null,
		printers: null,
		selectedPrinterName: null,
		selectedPrinterIP: null,
		tagTypeOfficial: null,
		tagTypeName: null,
		tagQuantity: null
	};

	constructor(props) {
		super(props);

		this.toggle = this.toggle.bind(this);
		this.state = {
			dropdownOpen: false
		};
		this.state.selectedLocation = this.props.location;
		this.state.tagQuantity = 1;
		this.getLocations();
		if (this.state.selectedLocation) this.getPrinters(this.state.selectedLocation);
	}

	toggle = () => {
		this.setState({
			dropdownOpen: !this.state.dropdownOpen
		});
	};

	getLocations = async () => {
		let locData = await api.getLocations();
		this.setState({locations: locData.data.stores});
	};

	setLocation = async location => {
		await this.setState({selectedLocation: location});
		// set location cookie
		this.getPrinters(location);
		this.props.handleLocationChange(location);
	};

	getPrinters = async storeId => {
		let printerData = await api.getPrinters(storeId);
		await this.setState({ printers: printerData.data.printers });

	};

	setPrinter = (printerName, printerIP) => {
		this.setState({ selectedPrinterName: printerName });
		this.setState({ selectedPrinterIP: printerIP });
	};

	setTagType = (tagTypeOfficial, tagTypeName) => {
		this.setState({ tagTypeOfficial: tagTypeOfficial });
		this.setState({ tagTypeName: tagTypeName });
	};

	quantityUp = async () => this.setState({tagQuantity: this.state.tagQuantity + 1});
	quantityDown = async () => {if (this.state.tagQuantity > 1) this.setState({ tagQuantity: this.state.tagQuantity - 1 })};

	alertBox = message => {
		Alert.success(`${message}`, {
			position: 'top-left',
			effect: 'slide',
			timeout: 3000
		});
	};

	printTag = () => {
		if (this.props.sku === undefined) {
			this.alertBox("Must select sku before printing tag.");
		} else if (this.state.selectedLocation === undefined) {
			this.alertBox("Must select a store before printing tag.");
		} else if (this.state.selectedPrinterIP === undefined) {
			this.alertBox("Must select a printer before printing tag.");
		} else if (this.state.tagTypeOfficial === undefined) {
			this.alertBox("Must select a tag type before printing tag.");
		} else {
			this.alertBox("Printing tag!");
			api.getPrintTags(this.props.sku, this.state.selectedLocation, this.state.selectedPrinterIP, this.state.tagTypeOfficial, this.state.tagQuantity);
		}
	};

	render = () => (
		<Col>
			<TagPrintDiv>
				<DropdownsButtonGroup vertical>
					{this.state.locations ? <TagSites defaultText="Select Store" selectedLocation={this.state.selectedLocation} locations={this.state.locations} setLocation={this.setLocation} /> : null}
					{this.state.printers ? <TagPrinters defaultText="Select Printer" selectedPrinterName={this.state.selectedPrinterName} printers={this.state.printers} setPrinter={this.setPrinter} /> : null}
					<TagType defaultText="Select Tag Type" tagTypeName={this.state.tagTypeName} setTagType={this.setTagType} />
				</DropdownsButtonGroup>
				<QuantityButtonGroup>
					<QuantityAdjustButton onClick={() => this.quantityDown()}>-</QuantityAdjustButton>
					<QuantityButton>{this.state.tagQuantity}</QuantityButton>
					<QuantityAdjustButton onClick={() => this.quantityUp()}>+</QuantityAdjustButton>
				</QuantityButtonGroup>
				<PrintButton printTag={this.printTag} />
			</TagPrintDiv>
		</Col>
	);
}

export default TagPrinting;
