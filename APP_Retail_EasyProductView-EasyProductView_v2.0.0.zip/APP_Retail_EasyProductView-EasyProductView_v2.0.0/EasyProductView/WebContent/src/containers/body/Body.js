import React, { Component, Fragment } from 'react';
import { Route } from 'react-router-dom';
import { Col, Row } from 'reactstrap';
import styled from 'styled-components';
import SearchResults from './SearchResults';
import ProductDetails from './ProductDetails';
import Modal from '../../components/ui/Modal';
import * as api from '../../api';

const ColTable = styled(Col)`
	display: block;
	height: 75%;
`;

class Body extends Component {
	state = {
		text: this.props.text,
		itemId: this.props.itemId,
		sku: this.props.sku,
		upc: this.props.upc,
		results: [],
		inventory: [],
		showModal: false
	};

	setInventory = inventory => this.setState({ inventory });
	setResults = results => this.setState({ results });
	setItemId = itemId => this.setState({ itemId });
	setUpc = async sku => {
		if (sku == null) {
			this.setState({ upc: '' })
		} else {
			const upc = await api.getUPCfromSKU(sku);
			if (upc.data == null) {
				this.setState({ upc: '' })
			} else {
				this.setState({ upc: upc.data.skus[0].upc })
			}
		}
	}
	setSku = sku => {
		this.setUpc(sku); // tacking this on as a part of setting sku since UPC will change every time SKU changes
		this.setState({ sku });
	}

	componentDidUpdate = ({ text, itemId, sku, upc }) => {
		if (text !== this.props.text || itemId !== this.props.itemId || sku !== this.props.sku || upc !== this.props.upc) {
			this.setState({ text: this.props.text, itemId: this.props.itemId, sku: this.props.sku, upc: this.props.upc });
		}
	};

	showModal = () => {
		this.setState({ showModal: true });
	}

	hideModal = () => {
		this.setState({ showModal: false });
	}
	
	render = () => (
		<Fragment>
			<Route path="/product" render={() => (
				<Row>
					<Modal show={this.state.showModal} />
					<ProductDetails showModal={this.showModal} hideModal={this.hideModal} location={this.props.location} handleLocationChange={this.props.handleLocationChange} itemId={this.state.itemId} sku={this.state.sku} upc={this.state.upc} inventory={this.state.inventory} setInventory={this.setInventory} setSku={this.setSku} setItemId={this.setItemId} />
				</Row>
			)} />
			<Route path="/search" render={() => (
				<ColTable xs="12">
					<Modal show={this.state.showModal} />
					<SearchResults showModal={this.showModal} hideModal={this.hideModal} text={this.state.text} results={this.state.results} setResults={this.setResults} />
				</ColTable>
			)} />
		</Fragment>
	);
}

export default Body;
