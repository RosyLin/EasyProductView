import React, { Component } from 'react';
import { Table as RsTable } from 'reactstrap';
import styled from 'styled-components';
import { IconContext } from 'react-icons/lib';
import { TiArrowUnsorted } from 'react-icons/ti';
import { GREEN } from '../../constants';

const TableSmall = styled(RsTable) `
	display: table;
	width: 98%;
	position: absolute;

	@media only all and (min-width: 348px) and (max-width: 540px) {
		margin-left: -15px;
	}
`;

const THeadHead = styled.thead`
	color: white;
	background-color: ${GREEN};
	height: 2%;
`;

const TBodyBody = styled.tbody`
	position: absolute;
	max-height: 1500%;
	width: 100%;
	overflow: auto;
`;

const THHeader = styled.th`
	cursor: pointer;
`;

const TRRow = styled.tr`
	${({ clickable }) => clickable && 'cursor: pointer;'}
	width: 100%;
	max-width: 100%;
	display: table;
`;

const SpanRed = styled.span`
	color: red;
`;

const TD = styled.td`
	word-break: break-word;
	font-size: 15px;
`

const value = {
	size: '1.25em',
	style: {
		position: 'relative',
		top: '-2px'
	}
};

class Table extends Component {
	state = {
		shouldReverse: false,
		shouldSort: false
	};

	sortIndex = -1;

	sort = (rowA, rowB) => {
		let a = rowA.props.children;
		let b = rowB.props.children;

		if (this.sortIndex === 0) {
			a = a[this.sortIndex].props.children;
			b = b[this.sortIndex].props.children;
		} else {
			a = a[1][this.sortIndex - 1].props.children;
			b = b[1][this.sortIndex - 1].props.children;
		}

		if (typeof a === 'string') {
			const aParsed = parseFloat(a.replace('$', ''));
			const bParsed = parseFloat(b.replace('$', ''));

			if (!isNaN(aParsed)) {
				return aParsed < bParsed ? -1 : aParsed === bParsed ? 0 : 1;
			}
		}

		return a < b ? -1 : a === b ? 0 : 1;
	};

	onClick = ({ currentTarget }) => {
		const sortIndex = Array.from(currentTarget.parentElement.children).indexOf(currentTarget);

		if (sortIndex === this.sortIndex && !this.state.shouldReverse) {
			this.setState({ shouldSort: false, shouldReverse: true });
		} else {
			this.sortIndex = sortIndex;

			this.setState({ shouldSort: true, shouldReverse: false });
		}
	};

	renderRows = () => {
		const rows = this.props.rows.map(row => (
			<TRRow key={row[this.props.header]} clickable={this.props.onClick} {...{ onClick: this.props.onClick && (() => this.props.onClick(row[this.props.header])) }}>
				<th width={this.props.widths[0] + '%'}>{row[this.props.header]}</th>
				{this.props.data.map((data, index) => <TD key={data} width={this.props.widths[index + 1] + '%'}>{row[data]}</TD>)}
			</TRRow>
		));

		if (this.state.shouldSort) {
			rows.sort(this.sort);
		}

		if (this.state.shouldReverse) {
			rows.sort(this.sort).reverse();
		}

		return rows;
	};

	render = () => {
		if (this.props.rows[0] && !this.props.awaitingResults) {
			return (
				<TableSmall striped hover={!!this.props.onClick}>
					<THeadHead>
						<tr>
							<IconContext.Provider value={value}>
								{this.props.headers.map((header, index) => <THHeader key={header} width={this.props.widths[index] + '%'} onClick={this.onClick}><TiArrowUnsorted /> {header}</THHeader>)}
							</IconContext.Provider>
						</tr>
					</THeadHead>
					<TBodyBody>
						{this.renderRows()}
					</TBodyBody>
				</TableSmall>
			);
		} else if(this.props.awaitingResults) {
			return (
				<SpanRed></SpanRed>
			);
		} else {
			return (
				<SpanRed>No results. Please try a different search term.</SpanRed>
			);
		}
	};
}

export default Table;
