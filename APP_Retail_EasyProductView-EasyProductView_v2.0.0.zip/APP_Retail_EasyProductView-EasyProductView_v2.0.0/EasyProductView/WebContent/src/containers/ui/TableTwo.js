import React, { Component } from 'react';
import { Table as RsTable } from 'reactstrap';
import styled from 'styled-components';
import { TiArrowUnsorted } from 'react-icons/ti';
import { GREEN } from '../../constants';


const TH = styled.th`
	background-color: ${GREEN};
	color: white;

	:hover {
		cursor: pointer;
		font-size: 14pt;
	}
`;

const SpanRed = styled.span`
	color: red;
`;

class TableTwo extends Component {

	state = {
		shouldReverse: false,
		shouldSort: false
	};

	sortIndex = -1;

	sort = (rowA, rowB) => {
		let a = rowA.props.children[this.sortIndex].props.children;;
		let b = rowB.props.children[this.sortIndex].props.children;;

		if (typeof a === 'string') {
			const aParsed = parseFloat(a.replace('$', ''));
			const bParsed = parseFloat(b.replace('$', ''));

			if (!isNaN(aParsed)) {
				return aParsed < bParsed ? -1 : aParsed === bParsed ? 0 : 1;
			}
		}

		return a < b ? -1 : a === b ? 0 : 1;
	};

	onClick = ({ currentTarget }) => {
		const sortIndex = Array.from(currentTarget.parentElement.children).indexOf(currentTarget);

		if (sortIndex === this.sortIndex && !this.state.shouldReverse) {
			this.setState({ shouldSort: false, shouldReverse: true });
		} else {
			this.sortIndex = sortIndex;

			this.setState({ shouldSort: true, shouldReverse: false });
		}
	};

	renderRows = () => {
		// console.log(this.props.sku);
		if (this.props.rows[0]) {
			const rows = this.props.rows.map(row => (
				<tr key={row[this.props.header]} >
					<td width="25%">{row[this.props.header]}</td>
					<td width="50%">{row.location}</td>
					<td width="25%">{row.onHandQty}</td>
				</tr>
			));

			if (this.state.shouldSort) {
				rows.sort(this.sort);
			}

			if (this.state.shouldReverse) {
				rows.sort(this.sort).reverse();
			}

			return rows;
		}

		// console.log(this.props.sku);
		if (this.props.sku) {
			// console.log("no available inventory");
			const noInvRow = (
				<tr><td colSpan="3"><SpanRed>No available inventory for item.</SpanRed></td></tr>
			);
			return noInvRow;
		} else {
			// console.log("need to select sku still");
			const selectSkuRow = (
				<tr><td colSpan="3"><SpanRed>Please select a specific sku to view its inventory.</SpanRed></td></tr>
			);
			return selectSkuRow;
		}

			
	};

	render = () => {
		return (
			<RsTable striped>
				<thead>
					<tr>
						<TH width="25%" onClick={this.onClick}><TiArrowUnsorted /> Site ID</TH>
						<TH width="50%" onClick={this.onClick}><TiArrowUnsorted /> Store</TH>
						<TH width="25%" onClick={this.onClick}><TiArrowUnsorted /> Quantity</TH>
					</tr>
				</thead>
				<tbody>
					{this.renderRows()}
				</tbody>
			</RsTable>
		);

	};
}

export default TableTwo;
